package aiaTest;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Boolean loop = true;
		int canvas = 0; // No canvas yet
		String[][] cvArr = null;
		CanvasClass cvClass = new CanvasClass();
		
		while (loop) {
			Scanner sc= new Scanner(System.in);    //System.in is a standard input stream  
			System.out.println("C to create a canvas first, L to create a line, R to create a rectangle");
			System.out.print("Input : ");
			
			String a= sc.nextLine();
			sc.close();
			
			if (canvas == 0) { // No canvas
				cvArr = cvClass.createCnvas(cvArr, a);
				if (cvArr.equals(null)) {
					canvas = 0;
					continue;
				} else {
					canvas = 1;
				}
			} else {
				
				if(a.startsWith("L")) { //MAKE line
					cvArr = cvClass.createLine(cvArr, a);
				} else if (a.startsWith("R")) { // MAKE rectangle
					cvArr = cvClass.createRect(cvArr, a);
				} else if (a.startsWith("B")) { // FILL color
					cvArr = cvClass.createLine(cvArr, a);
				} else if (a.startsWith("Q")){ // EXIT
					loop = false;
					System.exit(0);
				} else {
					System.out.println("Sorry, not a registered input");
				}
			}
		}
	}
}
