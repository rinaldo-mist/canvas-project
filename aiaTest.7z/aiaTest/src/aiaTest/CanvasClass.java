package aiaTest;

public class CanvasClass {
	
	public String[][] createCnvas(String[][] cvArr, String a) {
		if(!(a.startsWith("C"))) {
			System.out.println("Create your canvas first");
			cvArr = null;
		} else {
			String[] cmd = a.split(" ");
			int w = Integer.parseInt(cmd[1])+2;
			int h = Integer.parseInt(cmd[2])+2;
			cvArr = new String[w][h];
			//PRINT first and last row
			for(int ct = 0 ; ct < w ; ct++) {
				if(ct == 0 || ct == w-1) { // PRINT top and bottom line
					for(int ctR = 0 ; ctR < w ; ctR++) {
						cvArr[ct][ctR] = "-";
					}
				} else { // PRINT left and right border
					cvArr[ct][0]="|";
					cvArr[ct][h-1]="|";
				}
			}
		}
		return cvArr;
	}
	
	public String[][] createLine(String[][] cvArr, String a) {
		String[] cmd = a.split(" ");
		int x1 = Integer.parseInt(cmd[1]);
		int y1 = Integer.parseInt(cmd[2]);
		int x2 = Integer.parseInt(cmd[3]);
		int y2 = Integer.parseInt(cmd[4]);
		if(y1==y2) { // SAME ROW
			for(int anc1 = x1; anc1 <= x2 ; anc1++) {
				cvArr[anc1][y1]="x";
			}
		}
		else { // DIFFERENT ROW
			for(int anc1 = y1; anc1 <= y2 ; anc1++) {
				cvArr[x1][anc1]="x";
			}
		}
		
		System.out.println("Created a line");
		return cvArr;
	}
	
	public String[][] createRect(String[][] cvArr, String a) {
		String[] cmd = a.split(" ");
		int x1 = Integer.parseInt(cmd[1]);
		int y1 = Integer.parseInt(cmd[2]);
		int x2 = Integer.parseInt(cmd[3]);
		int y2 = Integer.parseInt(cmd[4]);
		 // TOP & BOTTOM ROW
			for(int anc1 = x1; anc1 <= x2 ; anc1++) {
				cvArr[anc1][y1]="x";
				cvArr[anc1][y2]="x";
			}
		
		// LEFT AND RIGHT COLUMN
			for(int anc1 = y1; anc1 <= y2 ; anc1++) {
				cvArr[x1][anc1]="x";
				cvArr[x2][anc1]="x";
			}
		System.out.println("Created a rectangle");
		return cvArr;
	}
	
	public String[][] fillCanvas(String[][] cvArr, String a) {
		String[] cmd = a.split(" ");
		int x1 = Integer.parseInt(cmd[1]);
		int y1 = Integer.parseInt(cmd[2]);
		String clr = cmd[3];
		
		System.out.println("Canvas filled");
		return cvArr;
	}

}
